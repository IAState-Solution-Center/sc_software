<?php
include('functions.php');

echo "<pre>";
print_r(getEmployees());
echo "</pre>";
?>
<br />
<font size='1'><table class='xdebug-error xe-uncaught-exception' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Fatal error: Uncaught ArgumentCountError: Too few arguments to function workingAssignment(), 1 passed in /Users/solutioncenter/repo/webServer/functions.php on line 21 and exactly 2 expected in /Users/solutioncenter/repo/webServer/functions.php on line <i>65</i></th></tr>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> ArgumentCountError: Too few arguments to function workingAssignment(), 1 passed in /Users/solutioncenter/repo/webServer/functions.php on line 21 and exactly 2 expected in /Users/solutioncenter/repo/webServer/functions.php on line <i>65</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0010</td><td bgcolor='#eeeeec' align='right'>452096</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='/Users/solutioncenter/repo/webServer/functions.php' bgcolor='#eeeeec'>.../functions.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0010</td><td bgcolor='#eeeeec' align='right'>452112</td><td bgcolor='#eeeeec'>workingAssignment(  )</td><td title='/Users/solutioncenter/repo/webServer/functions.php' bgcolor='#eeeeec'>.../functions.php<b>:</b>21</td></tr>
</table></font>